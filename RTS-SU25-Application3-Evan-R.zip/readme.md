# Readme

Theme: A Chasis Intrusion system where light is the trigger

Q1) Using the ISR means we can react to a button press the moment it happens, 
really useful when latency is super sensitive. Polling may cause latency issues, and 
requires cpu cycles to poll the button. This may also save some power if the button is pushed not often

Q2) We want to use ISR specific functions is because they are made in a way to prevent blocking which could be 
detrimental if they happened in the ISR. If they block all processed (such as our single core system) then it could starve
the whole CPU. Or with xSemaphoreTake it could block a bunch of processes and crash the system

Q3) When the button is pressed, it immediatly blocks the Light Sensor Task and does the button_isr_handler task.
It then unblocks the logger task, so it can be done, it needs to raise the priority above the light task so it
uses xHigherPriorityTaskWoken to raise it above the light task. The ISR then yeilds using portYIELD_FROM_ISR() and then
the sceduler runs again, and the logger runs premtivly before the light task.

Q4) We pinned eveyrhting on core 1 since we evade any tasks that run on core 0 like ESP background tasks, and we
can make sure everyting runs one at a time, keeping this deterministic. Also we keep coherency in our variables,
where if things were multicored we may have some race conditions we would need to program for

Q5) We use a Mutex to keep the logger task and ligtsensor task coherent so that values don't update while our
logger is trying to function. This can lead to corrupted or best case inaccurate logs

Q6) Assuming we give the logger task a lower proroity when running the button_isr, then it would run much later
as the blinking and light detecting tasks would block it from functioning. Basically the oposite reaction we want
our button to produce

Q7) Using the ISR minimizes the logger task and button tasks by only calling them really when needed (Logging still happens
but only when nessesary). We want to keep ISRs small since they are meant to interupt the system to do critical tasks,
if the ISr does alot in it, it will starve other processes and halt the system. It also freezes the scedulder, which 
idk about you but I like to stick to my sceduler

Q8) On page 244

"With hardware interrupts, we can now respond to events when the sensors or external systems determine there is an issue
to be dealt with. Each such event, however, requires a interrupt service routine (ISR) to execute, possibly pre-empting an
even higher priority task that is currently executing.
Responses to such events depend on the environment, and when such events are irregular, such an approach is desirable.
When there is no load on the system, event-triggered events ensure economic use of resources, but when the system is
overloaded, it is unlikely that the system will be designed to respond appropriately."

This is seen in the button setup, where we don't want to poll it often, this is a basic use of ISR where we use it
to pull forward a task that we want to only runn infrequently but want it to run when desired



